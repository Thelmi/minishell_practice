Editable PDF:
https://docs.google.com/document/d/1hzWC_Z1ipB_CkiIEDWVqqPAUmG4gmrUSCQvsy3oWEYs/edit?usp=sharing

CASES:
https://github.com/nafuka11/42_minishell_tester/tree/master/cases
